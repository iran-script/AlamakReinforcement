<!DOCTYPE html>
<html lang="fa" dir="rtl">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>@yield('title')</title>

    <link href="{{ url('css/bootstrap.min.css') }}" rel="stylesheet">
    <link href="{{  url('css/bootstrap-icon.css')  }}" rel="stylesheet">
    <link href="{{  url('css/boot-icon.css')  }}" rel="stylesheet">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://cdn.jsdelivr.net/npm/vazirmatn@33.0.3/Vazirmatn-font-face.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;500;600;700&display=swap" rel="stylesheet">

    <script src="{{ asset('js/sidebar.js') }}"></script>

    <style>
        /* ===================================================
           DESIGN TOKENS — «کنسول عملیات میدانی»
           پالت برگرفته از تابلوهای برق/گاز، پلاک‌های استامپ‌شده
           روی علمک‌ها، و کاغذ نقشه‌کشی مهندسی
        =================================================== */
        :root {
            --bg:        #0B1220;
            --panel:     #121B2E;
            --panel-2:   #16233A;
            --grid-line: #223252;
            --border:    #223252;
            --text:      #E7ECF5;
            --muted:     #8B9AB8;
            --muted-2:   #5C6B8A;

            --amber:     #F0A93B;
            --amber-ink: #3A2A0C;
            --teal:      #33C6B0;
            --teal-ink:  #08302A;
            --red:       #E5484D;
            --red-ink:   #3A1013;
            --blue:      #4C8DFF;

            --font-display: 'Vazirmatn', 'Segoe UI', Tahoma, sans-serif;
            --font-body:    'Vazirmatn', 'Segoe UI', Tahoma, sans-serif;
            --font-mono:    'JetBrains Mono', 'Courier New', monospace;

            --radius: 12px;
            --radius-sm: 8px;
        }

        * { box-sizing: border-box; }

        html, body {
            background: var(--bg);
        }

        body {
            font-family: var(--font-body);
            color: var(--text);
            overflow-x: hidden;
            background:
                radial-gradient(1100px 500px at 100% -10%, rgba(76, 141, 255, .10), transparent 60%),
                radial-gradient(900px 500px at -10% 110%, rgba(240, 169, 59, .08), transparent 55%),
                var(--bg);
            background-attachment: fixed;
        }

        /* faint blueprint grid overlay on the whole canvas */
        body::before {
            content: "";
            position: fixed;
            inset: 0;
            pointer-events: none;
            z-index: 0;
            background-image:
                linear-gradient(var(--grid-line) 1px, transparent 1px),
                linear-gradient(90deg, var(--grid-line) 1px, transparent 1px);
            background-size: 42px 42px;
            opacity: .12;
        }

        a { text-decoration: none; }

        /* ============== SIDEBAR — CONTROL RAIL ============== */
        #sidebar {
            width: 264px;
            height: 100vh;
            background: linear-gradient(180deg, #101827 0%, #0C1220 100%);
            border-inline-start: 1px solid var(--border);
            color: var(--text);
            position: fixed;
            right: 0;
            top: 0;
            transition: .25s ease;
            padding: 18px 14px;
            z-index: 1030;
            display: flex;
            flex-direction: column;
        }

        #sidebar.collapsed { width: 76px; }

        .rail-brand {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 6px 6px 16px 6px;
            border-bottom: 1px solid var(--border);
            margin-bottom: 12px;
        }

        .rail-brand .plate-mark {
            width: 38px;
            height: 38px;
            flex: 0 0 auto;
            border-radius: 8px;
            background: linear-gradient(155deg, #26344F, #131C2C);
            border: 1px solid var(--border);
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--amber);
            font-family: var(--font-mono);
            font-weight: 700;
            font-size: 14px;
            box-shadow: inset 0 0 0 1px rgba(255,255,255,.03);
        }

        .rail-brand .rail-title {
            font-weight: 800;
            font-size: 15px;
            line-height: 1.3;
            white-space: nowrap;
        }

        .rail-brand .rail-sub {
            font-size: 11px;
            color: var(--muted-2);
            font-family: var(--font-mono);
            letter-spacing: .04em;
        }

        #sidebar.collapsed .rail-title,
        #sidebar.collapsed .rail-sub { display: none; }

        .toggle-btn {
            background: var(--panel-2);
            color: var(--muted);
            border: 1px solid var(--border);
            width: 100%;
            padding: 9px;
            margin-bottom: 14px;
            border-radius: var(--radius-sm);
            font-size: 13px;
            transition: .2s;
        }

        .toggle-btn:hover { color: var(--amber); border-color: var(--amber); }

        .sidebar-user {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 8px 8px 14px;
            margin-bottom: 6px;
            font-size: 13px;
            color: var(--muted);
        }

        .sidebar-user .dot-live {
            width: 8px; height: 8px; border-radius: 50%;
            background: var(--teal);
            box-shadow: 0 0 0 3px rgba(51,198,176,.18);
            flex: 0 0 auto;
        }

        #sidebar hr { border-color: var(--border); opacity: 1; margin: 4px 0 10px; }

        .sidebar-nav { flex: 1; overflow-y: auto; }

        #sidebar a {
            color: var(--muted);
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 10px 10px;
            border-radius: var(--radius-sm);
            white-space: nowrap;
            font-size: 14px;
            transition: .15s;
            border-inline-start: 3px solid transparent;
        }

        #sidebar a i { font-size: 16px; width: 18px; text-align: center; color: var(--muted-2); }

        #sidebar a:hover { color: var(--text); background: rgba(255,255,255,.03); }
        #sidebar a:hover i { color: var(--amber); }

        #sidebar a span.text { margin-inline-start: 2px; }
        #sidebar.collapsed a span.text { display: none; }
        #sidebar.collapsed .menu-toggle { justify-content: center; }
        #sidebar.collapsed a { justify-content: center; }

        .menu-group { margin-bottom: 3px; }

        .menu-toggle { cursor: pointer; justify-content: space-between !important; }

        .submenu {
            display: none;
            margin-inline-start: 12px;
            padding-inline-start: 10px;
            border-inline-start: 1px dashed var(--border);
        }

        .submenu.show { display: block; }
        .submenu a { font-size: 13px; padding: 8px 10px; }

        .active-menu {
            background: linear-gradient(90deg, rgba(240,169,59,.14), rgba(240,169,59,0));
            color: var(--amber) !important;
            border-inline-start-color: var(--amber);
        }
        .active-menu i { color: var(--amber) !important; }

        .arrow { transition: .25s; color: var(--muted-2); font-size: 12px !important; }
        .menu-toggle.open .arrow { transform: rotate(180deg); }

        .sidebar-logout { border-top: 1px solid var(--border); padding-top: 10px; margin-top: 8px; }
        .sidebar-logout button {
            background: transparent;
            border: none;
            color: var(--muted);
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 10px;
            width: 100%;
            border-radius: var(--radius-sm);
            font-size: 14px;
        }
        .sidebar-logout button:hover { color: var(--red); background: rgba(229,72,77,.08); }

        /* ============== CONTENT ============== */
        #content {
            margin-inline-end: 264px;
            padding: 26px 28px 40px;
            transition: .25s ease;
            position: relative;
            z-index: 1;
            min-height: 100vh;
        }

        #content.full { margin-inline-end: 76px; }

        /* ============== SHARED COMPONENTS ============== */
        .panel, .card-box, .card, .card-custom {
            background: linear-gradient(180deg, var(--panel-2), var(--panel));
            border: 1px solid var(--border);
            border-radius: var(--radius);
            box-shadow: 0 10px 30px -18px rgba(0,0,0,.6);
            color: var(--text);
        }

        .card-header, .panel-head {
            background: rgba(255,255,255,.02) !important;
            border-bottom: 1px solid var(--border) !important;
            color: var(--text) !important;
            font-weight: 700;
        }

        .card.bg-primary.text-white, .card-header.bg-primary {
            background: linear-gradient(90deg, #17233B, #101827) !important;
            border-bottom: 1px solid var(--border) !important;
            color: var(--text) !important;
            position: relative;
        }
        .card-header.bg-primary::before {
            content: "";
            position: absolute; inset-inline-start: 0; top: 0; bottom: 0;
            width: 4px; background: var(--amber);
        }

        .table { color: var(--text); }
        .table thead.table-dark, .table thead.table-light {
            background: var(--panel-2) !important;
            color: var(--muted) !important;
            font-size: 12.5px;
            letter-spacing: .02em;
            text-transform: none;
        }
        .table-striped > tbody > tr:nth-of-type(odd) > * {
            background: rgba(255,255,255,.015);
            color: var(--text);
        }
        .table-hover > tbody > tr:hover > * {
            background: rgba(240,169,59,.06);
            color: var(--text);
        }
        .table-bordered, .table-bordered > :not(caption) > * { border-color: var(--border); }
        .table > :not(caption) > * > * { border-bottom-color: var(--border); }

        /* plate — پلاک استامپ‌شده کد علمک، موتیف اصلی طراحی */
        .plate {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            font-family: var(--font-mono);
            font-weight: 600;
            font-size: 13px;
            letter-spacing: .03em;
            color: var(--text);
            background: linear-gradient(155deg, #223252, #141E32);
            border: 1px solid var(--border);
            border-radius: 6px;
            padding: 4px 10px;
            box-shadow: inset 0 1px 0 rgba(255,255,255,.05), 0 2px 6px -2px rgba(0,0,0,.5);
        }
        .plate::before {
            content: "";
            width: 6px; height: 6px; border-radius: 50%;
            background: var(--muted-2);
        }
        .plate.plate-lg { font-size: 20px; padding: 8px 16px; }

        /* LED status dot — به‌جای بج‌های عمومی بوت‌استرپ */
        .led {
            display: inline-flex;
            align-items: center;
            gap: 7px;
            font-size: 13px;
            font-weight: 600;
            padding: 5px 12px 5px 8px;
            border-radius: 999px;
            background: rgba(255,255,255,.03);
            border: 1px solid var(--border);
        }
        .led::before {
            content: "";
            width: 8px; height: 8px; border-radius: 50%;
            box-shadow: 0 0 8px currentColor;
        }
        .led-done, .led-success { color: var(--teal); }
        .led-done::before, .led-success::before { background: var(--teal); }
        .led-pending, .led-warning { color: var(--amber); }
        .led-pending::before, .led-warning::before { background: var(--amber); }
        .led-reject, .led-danger { color: var(--red); }
        .led-reject::before, .led-danger::before { background: var(--red); }

        .btn { border-radius: var(--radius-sm); font-weight: 600; font-size: 14px; }
        .btn-primary {
            background: var(--amber); border-color: var(--amber); color: #1A1204;
        }
        .btn-primary:hover, .btn-primary:focus {
            background: #ffbb52; border-color: #ffbb52; color: #1A1204;
        }
        .btn-success { background: var(--teal); border-color: var(--teal); color: #06231D; }
        .btn-success:hover { background: #4fe0c9; border-color: #4fe0c9; }
        .btn-danger { background: var(--red); border-color: var(--red); }
        .btn-secondary { background: var(--panel-2); border-color: var(--border); color: var(--text); }
        .btn-secondary:hover { background: #1c2a44; border-color: var(--border); color: var(--text); }
        .btn-outline-danger { color: var(--red); border-color: rgba(229,72,77,.5); }
        .btn-outline-danger:hover { background: var(--red); border-color: var(--red); }

        .form-control, .form-select {
            background: var(--panel); border: 1px solid var(--border); color: var(--text);
        }
        .form-control:focus, .form-select:focus {
            background: var(--panel); border-color: var(--amber); color: var(--text);
            box-shadow: 0 0 0 .2rem rgba(240,169,59,.15);
        }
        .form-control::placeholder { color: var(--muted-2); }
        .form-label { color: var(--muted); font-size: 13px; font-weight: 600; }

        .modal-content { background: var(--panel); color: var(--text); border: 1px solid var(--border); }
        .modal-header, .modal-footer { border-color: var(--border) !important; }
        .btn-close { filter: invert(1) grayscale(1) brightness(1.8); }

        .page-title, h1, h2, h3, h4, h5 { font-family: var(--font-display); }

        ::-webkit-scrollbar { width: 8px; height: 8px; }
        ::-webkit-scrollbar-thumb { background: var(--border); border-radius: 10px; }
        ::-webkit-scrollbar-track { background: transparent; }

        @media (max-width: 768px) {
            #sidebar { transform: translateX(100%); }
            #sidebar.collapsed { transform: translateX(0); width: 264px; }
            #content, #content.full { margin-inline-end: 0; }
        }
    </style>

    @yield('styles')
</head>

<body>

    <x-sidebar />

    <!-- CONTENT -->
    <div id="content">

        @yield('content')

    </div>

    <script>
        function toggleSidebar() {
            document.getElementById('sidebar').classList.toggle('collapsed');
            document.getElementById('content').classList.toggle('full');
        }
    </script>

    <script>
        document.querySelectorAll('.menu-toggle').forEach(function(item) {

            item.addEventListener('click', function(e) {

                e.preventDefault();

                let id = this.dataset.menu;

                let submenu = document.getElementById('submenu' + id);

                this.classList.toggle('open');

                if (submenu.style.display == "block") {

                    submenu.style.display = "none";

                } else {

                    submenu.style.display = "block";

                }

            });

        });
    </script>

</body>

</html>
