@extends('layouts.app')

@section('title', 'لیست علمک ها')

@section('styles')
<style>
    .page-eyebrow {
        font-family: var(--font-mono);
        font-size: 12px;
        letter-spacing: .08em;
        color: var(--muted-2);
        margin-bottom: 4px;
    }
    .page-heading {
        display: flex;
        align-items: center;
        justify-content: space-between;
        flex-wrap: wrap;
        gap: 12px;
        margin-bottom: 18px;
    }
    .page-heading h4 { font-weight: 800; margin: 0; }
    .index-toolbar {
        display: flex;
        align-items: center;
        gap: 10px;
        color: var(--muted);
        font-size: 13px;
    }
    .riser-row-code { font-weight: 700; }
    .id-cell { color: var(--muted-2); font-family: var(--font-mono); font-size: 12.5px; }
    .op-btns .btn { padding: 6px 12px; font-size: 12.5px; }
</style>
@endsection

@section('content')

<div class="container-fluid">

    <div class="page-eyebrow">REGISTRY / RISERS</div>
    <div class="page-heading">
        <h4><i class="bi bi-collection text-warning"></i> لیست علمک‌ها</h4>
        <div class="index-toolbar">
            <i class="bi bi-info-circle"></i>
            مجموع رکوردهای ثبت‌شده در سامانه
        </div>
    </div>

    <div class="panel">

        <div class="card-body">

            <div class="table-responsive">

                <table class="table table-striped table-hover table-bordered align-middle mb-0">

                    <thead class="table-dark">
                        <tr>
                            <th width="80">ID</th>
                            <th>کد علمک</th>
                            <th>وضعیت</th>
                            <th width="170">عملیات</th>
                        </tr>
                    </thead>

                    <tbody>

                    @forelse($risers as $riser)

                        <tr>
                            <td class="id-cell">#{{ $riser->id }}</td>
                            <td>
                                <span class="plate">{{ $riser->r_giscode }}</span>
                            </td>
                            <td>
                                @php
                                    $doneStatuses   = ['تعمیر شده', 'انجام شده'];
                                    $rejectStatuses = ['رد شده'];
                                    $ledClass = in_array($riser->status, $doneStatuses)
                                        ? 'led-done'
                                        : (in_array($riser->status, $rejectStatuses) ? 'led-reject' : 'led-pending');
                                @endphp
                                <span class="led {{ $ledClass }}">{{ $riser->status }}</span>
                            </td>

                            <td class="op-btns">
                                <a href="#"
                                   class="btn btn-sm btn-primary">
                                    <i class="bi bi-eye"></i>
                                    مشاهده
                                </a>

                                <a href="#"
                                   class="btn btn-sm btn-secondary">
                                    <i class="bi bi-clock-history"></i>
                                    تغییرات
                                </a>
                            </td>
                        </tr>

                    @empty

                        <tr>
                            <td colspan="4" class="text-center py-4" style="color: var(--muted);">
                                <i class="bi bi-inbox" style="font-size: 22px;"></i>
                                <div class="mt-2">هیچ رکوردی یافت نشد</div>
                            </td>
                        </tr>

                    @endforelse

                    </tbody>

                </table>

            </div>

            <div class="mt-3">
                {{ $risers->links() }}
            </div>

        </div>

    </div>

</div>

@endsection
